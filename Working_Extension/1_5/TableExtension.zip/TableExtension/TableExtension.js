/*globals define*/
define( ["qlik", "jquery", "text!./style.css"], function ( qlik, $, cssContent ) {
	'use strict';
	$( "<style>" ).html( cssContent ).appendTo( "head" );
	// ---------- 追加 ここから (背景色・テキストの色設定) ----------
	function cellToColor(cell, expressionNumber) {
		// expressionNumber
		// => 0: 背景色
		// => 1: テキストの色

		// プロパティが存在するか確認
		if(cell.qAttrExps !== undefined){
			if(cell.qAttrExps.qValues !== undefined){
				if(cell.qAttrExps.qValues[expressionNumber] !== undefined){
					const colorNum = cell.qAttrExps.qValues[expressionNumber].qNum;
					if (isNaN(colorNum)){
						return null;
					}
					// Qlik Senseの色表現はARGB, CSSはRGBAなので順序を変換する
					const argb = ('00000000' + colorNum.toString(16)).slice(-8); // 10進数→16進数、桁数が足りない場合0埋めする
					const a = parseInt(argb.slice(0, 2), 16);
					const r = parseInt(argb.slice(2, 4), 16);
					const g = parseInt(argb.slice(4, 6), 16);
					const b = parseInt(argb.slice(6, 8), 16);
					if(!isNaN(a) && !isNaN(r) && !isNaN(g) && !isNaN(b)){
						return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
					}
				}
			}
		}
		// 色情報が存在しない、もしくはRGB(), ARGB()のフォーマットではない場合nullを返す
		return null;
	}
	// ---------- 追加 ここまで ----------

	function createRows ( rows, dimensionInfo ) {
		var html = "";
		rows.forEach( function ( row ) {
			html += '<tr class=>';
			row.forEach( function ( cell, key ) {
				if ( cell.qIsOtherCell ) {
					cell.qText = dimensionInfo[key].othersLabel;
				}
				html += "<td ";
				if ( !isNaN( cell.qNum ) ) {
					html += "class='numeric qv-st-value-overflow'";
				}
				// ---------- 追加 ここから (行を選択) ----------
				if (cell.qState === "O" || cell.qState === "S"){
					// 列が "O" or "S" のときのみ属性を追加
                    // "O" => option(白状態)
                    // "S" => selected(緑状態) 
                    // "X" => excluded(灰色状態)
                    // "L" => 数式
					html += " qDim ";
					html += " qElemNumber='" + cell.qElemNumber + "' ";
					html += " qDimNumber='" + key + "' ";
				}
				// ---------- 追加 ここまで ----------
				// ---------- 追加 ここから (背景色・テキストの色設定) ----------
				if (cell.qState === "L"){
					// 列が"L"のときのみスタイルを追加
					html += "style='"

					// セルから色情報を取得
					var backgroundColor = cellToColor(cell, 0);
					var textColor = cellToColor(cell, 1);

					// 背景色を指定
					if (backgroundColor){
						html += "background-color: " + backgroundColor + "; ";
					}

					// テキストの色を指定
					if (textColor){
						html += "color: " + textColor + "; ";
					}

					// style属性の終わり
					html += "' ";
				}
				html += "><div class='qv-st-data-cell ng-scope qv-st-data-cell-dimension-value qv-st-data-cell-numeric'><div class='qv-st-value'><div class='ng-binding ng-scope'>" + cell.qText + '</div></div></div></td>';
				// ---------- 追加 ここまで ----------
			} );
			html += '</tr>';
		} );
		return html;
	}

	return {
		initialProperties: {
			qHyperCubeDef: {
				qDimensions: [],
				qMeasures: [],
				qInitialDataFetch: [{
					qWidth: 10,
					qHeight: 50
				}]
			}
		},
		definition: {
			type: "items",
			component: "accordion",
			items: {
				dimensions: {
					uses: "dimensions",
					min: 1
				},
				measures: {
					uses: "measures",
					min: 0,
					// ---------- 追加 ここから (背景色・テキストの色設定) ----------
					items: {
						backgroundColor: {
							type: "dual",
							component: 'expression',
							label: "背景色",
							ref: "qAttributeExpressions.0.qExpression",
							expression: "always",
							defaultValue: ""
						},
						textColor: {
							type: "dual",
							component: 'expression',
							label: "テキストの色",
							ref: "qAttributeExpressions.1.qExpression",
							expression: "always",
							defaultValue: ""
						}
					}
					// ---------- 追加 ここまで ----------
				},
				sorting: {
					uses: "sorting"
				},
				settings: {
					uses: "settings"
				}
			}
		},
		snapshot: {
			canTakeSnapshot: true
		},
		paint: function ( $element, layout ) {
			var html = "<table><thead><tr class='qv-st-header-wrapper'><div class='qv-st-header'>", self = this,
				morebutton = false,
				hypercube = layout.qHyperCube,
				rowcount = hypercube.qDataPages[0].qMatrix.length,
				colcount = hypercube.qDimensionInfo.length + hypercube.qMeasureInfo.length;
			//render titles
			hypercube.qDimensionInfo.forEach( function ( cell ) {
				html += '<th>' + cell.qFallbackTitle + '</th>';
			} );
			hypercube.qMeasureInfo.forEach( function ( cell ) {
				html += '<th>' + cell.qFallbackTitle + '</th>';
			} );
			html += "</div></tr></thead><tbody>";
			//render data
			html += createRows( hypercube.qDataPages[0].qMatrix, hypercube.qDimensionInfo );
			html += "</tbody></table>";
			//add 'more...' button
			if ( hypercube.qSize.qcy > rowcount ) {
				html += "<button class='more'>More...</button>";
				morebutton = true;
			}
			$element.html( html );
			if ( morebutton ) {
				$element.find( ".more" ).on( "click", function () {
					var requestPage = [{
						qTop: rowcount,
						qLeft: 0,
						qWidth: colcount,
						qHeight: Math.min( 50, hypercube.qSize.qcy - rowcount )
					}];
					self.backendApi.getData( requestPage ).then( function ( dataPages ) {
						rowcount += dataPages[0].qMatrix.length;
						if ( rowcount >= hypercube.qSize.qcy ) {
							$element.find( ".more" ).hide();
						}
						var html = createRows( dataPages[0].qMatrix, hypercube.qDimensionInfo );
						$element.find( "tbody" ).append( html );
					} );
				} );
			}
			// ---------- 追加 ここから (行を選択)  ----------
			// クリックされたときの処理
			$element.find("td").on("click", function() {
				// 列が軸ではないときは何もしない
				if (!this.hasAttribute("qDim")){
					return
				}

				// セルの背景色を変更する
				this.setAttribute("style", "background-color: #00ff00");

				// パラメータを取得して項目を選択する
				var qDimNumber = parseInt(this.getAttribute("qDimNumber"));
				var qElemNumber = parseInt(this.getAttribute("qElemNumber"));
				self.backendApi.selectValues(qDimNumber, [qElemNumber], true);
			})
			// ---------- 追加 ここまで ----------
			return qlik.Promise.resolve();
		}
	};
} );
